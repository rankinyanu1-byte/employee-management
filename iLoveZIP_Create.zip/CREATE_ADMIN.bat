@echo off
setlocal enabledelayedexpansion
title Create PulseDesk Trial Login

echo.
echo ================================================
echo   Create Trial Login Account
echo ================================================
echo.
echo This script will create the trial login account in PulseDesk.
echo.

set ADMIN_EMAIL=trial@pulsedesk.local
set ADMIN_PASSWORD=TrialDesk@2026
set ADMIN_NAME=Trial User

echo Login Email: %ADMIN_EMAIL%
echo Login Password: %ADMIN_PASSWORD%
echo Display Name: %ADMIN_NAME%
echo.
echo ================================================
echo.

set PY=
if exist "%~dp0backend\venv\Scripts\python.exe" (
    set PY=%~dp0backend\venv\Scripts\python.exe
    goto :py_found
)
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe
    goto :py_found
)
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe
    goto :py_found
)
where py >nul 2>nul
if %errorlevel% equ 0 ( set PY=py && goto :py_found )

echo [ERROR] Python not found.
pause & exit /b 1

:py_found
cd /d "%~dp0backend"
echo Running trial login creation script...
echo.

%PY% -m app.db.seed

echo.
echo ================================================
echo   Trial login account created successfully!
echo ================================================
echo.
echo Login with these credentials:
echo   Email: %ADMIN_EMAIL%
echo   Password: %ADMIN_PASSWORD%
echo.
pause
