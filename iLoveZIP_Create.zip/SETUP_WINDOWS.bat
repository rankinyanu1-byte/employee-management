@echo off
title PulseDesk — First Time Setup
color 0A
echo.
echo ================================================
echo   PulseDesk v4 — First Time Setup
echo ================================================
echo.
echo BEFORE RUNNING: Make sure PostgreSQL is running
echo and you have created a database named "pulsedesk_trial".
echo.
echo In pgAdmin or psql, run:
echo   CREATE DATABASE pulsedesk_trial;
echo.
pause

set ROOT=%~dp0
set BACKEND=%ROOT%backend
set FRONTEND=%ROOT%frontend

REM ─── Find Python 3.11 ─────────────────────────────────────────────────────
set PY=
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe
    goto :py_found
)
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe
    goto :py_found
)
if exist "C:\Program Files\Python311\python.exe" (
    set "PY=C:\Program Files\Python311\python.exe"
    goto :py_found
)
if exist "C:\Python311\python.exe" (
    set PY=C:\Python311\python.exe
    goto :py_found
)
where py >nul 2>nul
if %errorlevel% equ 0 ( set PY=py && goto :py_found )

echo [ERROR] Python not found.
echo Download from: https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe
echo Check "Add Python to PATH" during install, then run this again.
pause & exit /b 1

:py_found
echo [OK] Python: %PY%
echo %PY%> "%ROOT%python_path.txt"
echo.

REM ─── Backend venv + packages ──────────────────────────────────────────────
echo [1/5] Creating backend virtual environment...
cd /d "%BACKEND%"
"%PY%" -m venv venv
if errorlevel 1 ( echo [ERROR] venv failed && pause && exit /b 1 )

echo [2/5] Installing backend packages (may take 2-3 minutes)...
"%BACKEND%\venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
"%BACKEND%\venv\Scripts\python.exe" -m pip install -r requirements.txt --quiet
if errorlevel 1 ( echo [ERROR] pip install failed && pause && exit /b 1 )
"%BACKEND%\venv\Scripts\python.exe" -m pip install fpdf2 --quiet
echo [OK] Backend packages installed

REM ─── .env setup ───────────────────────────────────────────────────────────
echo [3/5] Setting up environment config...
if not exist "%BACKEND%\.env" (
    copy "%BACKEND%\.env.example" "%BACKEND%\.env" >nul
    echo.
    echo *** Opening .env for you to set your PostgreSQL password ***
    echo *** Change: YOUR_PASSWORD to your actual PostgreSQL password ***
    echo.
    notepad "%BACKEND%\.env"
    echo Press any key after saving .env...
    pause >nul
) else (
    echo [OK] .env already exists
)

REM ─── Database migration ───────────────────────────────────────────────────
echo [4/5] Running database migrations...
cd /d "%BACKEND%"
"%BACKEND%\venv\Scripts\python.exe" -m alembic upgrade head
if errorlevel 1 (
    echo [ERROR] Migration failed. Check .env DATABASE_URL and ensure PostgreSQL is running.
    pause & exit /b 1
)
echo [OK] Database ready

REM ─── Fix metadata column if upgrading from old version ────────────────────
"%BACKEND%\venv\Scripts\python.exe" -c "
import asyncio
async def fix():
    try:
        from app.db.session import AsyncSessionLocal
        from sqlalchemy import text
        async with AsyncSessionLocal() as db:
            r = await db.execute(text(\"SELECT column_name FROM information_schema.columns WHERE table_name='anomaly_logs' AND column_name='metadata'\"))
            if r.fetchone():
                await db.execute(text('ALTER TABLE anomaly_logs RENAME COLUMN metadata TO event_metadata'))
                await db.commit()
                print('[OK] Fixed anomaly_logs column')
            else:
                print('[OK] Database schema is correct')
    except Exception as e:
        print(f'[WARN] Column fix skipped: {e}')
asyncio.run(fix())
" 2>nul

REM ─── Create admin ─────────────────────────────────────────────────────────
echo [5/5] Creating trial login account...
set ADMIN_EMAIL=trial@pulsedesk.local
set ADMIN_PASSWORD=TrialDesk@2026
set ADMIN_NAME=Trial User
"%BACKEND%\venv\Scripts\python.exe" -m app.db.seed
echo.

REM ─── Frontend packages ────────────────────────────────────────────────────
echo [6/6] Installing frontend packages...
cd /d "%FRONTEND%"
call npm install --silent
if errorlevel 1 ( echo [ERROR] npm install failed && pause && exit /b 1 )
echo [OK] Frontend ready

echo.
echo ================================================
echo   Setup Complete!
echo ================================================
echo.
echo   Login: trial@pulsedesk.local
echo   Pass:  TrialDesk@2026
echo.
echo   Run START_WINDOWS.bat to launch PulseDesk.
echo ================================================
pause
