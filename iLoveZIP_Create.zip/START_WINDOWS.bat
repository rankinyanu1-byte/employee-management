@echo off
title PulseDesk
color 0A

set ROOT=%~dp0
set BACKEND=%ROOT%backend
set FRONTEND=%ROOT%frontend
set VENV_PY=%BACKEND%\venv\Scripts\python.exe

if not exist "%VENV_PY%" (
    echo [ERROR] Backend not set up yet.
    echo Please run SETUP_WINDOWS.bat first.
    pause
    exit /b 1
)

echo Starting PulseDesk...

REM Start backend
start "PulseDesk Backend" cmd /k "cd /d "%BACKEND%" & "%VENV_PY%" -m uvicorn app.main:app --port 8000 --host 0.0.0.0"

timeout /t 3 /nobreak >nul

REM Start frontend  
start "PulseDesk Frontend" cmd /k "cd /d "%FRONTEND%" & npm run dev"

timeout /t 5 /nobreak >nul

start http://localhost:5173

echo.
echo ================================================
echo   PulseDesk is running!
echo   Dashboard : http://localhost:5173
echo   API Docs  : http://localhost:8000/api/docs
echo   Join URL  : http://localhost:8000/join
echo   Login     : trial@pulsedesk.local / TrialDesk@2026
echo ================================================
echo.
echo Both servers are running in separate windows.
echo Close those windows to stop the servers.
pause
